DynamicCall 1.0
By Paul Guerra




What is DynamicCall?
�������������������
DynamicCall is an ActiveX DLL made in Visual Basic 6 that lets you call functions from dynamically loaded libraries (in most cases DLLs). This is impossible to do directly in Visual Basic.
With DynamicCall you can use a library even if you don't know its name at design time, or use a heavy library and unload it when it is not needed anymore, or you can delete a library after using it (in VB you cannot do this since the library is not freed until the end of the program).




How do I use DynamicCall?
������������������������
There are two main types of calls you can perform with DynamicCall:

1. calls to functions from DLLs
2. 'callbacks' (i.e. calling a function by its address instead of its name)



1) Calling functions from DLLS
������������������������������
First of all, you load the library you want to use. You can have as many loaded libraries as you want. Once loaded, you define the functions you want to call. When you define a function, you are telling DynamicCall what parameters it needs and what data type it returns. Then you call the functions of the library. When you don't need the library anymore, you just unload it.

Libraries are loaded by a Loader. Generally you only have one Loader per application. A Loader is an instance of the class dynLoader:

Dim Loader As New dynLoader

Each library needs its own library object. A library object is an instance of the class dynLib:

Dim User32 As dynLib

You use the method LoadLibrary of the Loader to load a library:

Set User32 = Loader.LoadLibrary("user32")

Now you must define the function or functions you want to use.

User32.DefineFunction "MessageBox", "MessageBoxA", "%I4 %Str %Str %I4", "I4"

This line defines the function 'MessageBox' (which is actually called 'MessageBoxA'). It requires four parameters: a long, two strings, and a long. The '%' indicates the parameters must be passed by value. You can specify '&' to indicate the parameter has to be passed by reference. If you don't specify the passing method, it is assumed by value. Refer to the file 'Syntax.txt' for information about parameters. The return type of the function is a long.

User32.DefineFunction "GetWindowThreadProcessId", , "%I4 &I4", "I4"

Here we define the function 'GetWindowThreadProcessId' (that's the real name). It requires two parameters: a long, and a byref long. The return type is a long.

When you have all the functions declared, you just call the function directly:

User32("MessageBox").DoCall 0, "HelloWorld !!!", "Dynamic function call", vbInformation

And that's it. Now to unload the library you call the method Free of the library object:

User32.Free

If you need the error code of the last API call, use the property LastDLLError of the library object:

If User32.LastDLLError <> 0 Then MsgBox "Error", vbCritical



2) Calling a function by its address
������������������������������������

If you know the entry point of a function, you can use an instance of the class dynCaller to call it. (It is not limited to libraries' functions. You can even call your own functions by using the AddressOf operator). For example:

Dim Caller As New dynCaller
...
Caller.DefineFunction "MySub", AddressOf MySub, "%I4"
Caller.DoCall "MySub", 8
...
Sub MySub(ByVal P As Long)
...
End Sub




Notes about DynamicCall
�����������������������
* DynamicCall uses the stdcall calling convention. This means parameters are passed from right to left, and the function must clean up the stack.

* If you don't specify the return data type in a function definition, when you call the function it will return NULL.

* When passing parameters by reference, DynamicCall copies the parameter to a temporal variable, passes the address of that variable, calls the function, and then copies the temporal variable back to the parameter.

* You can pass at most 5 byref parameters of a given type when calling a function (i.e. 5 byref longs, 5 byref integers, etc).

* Calling a function through DynamicCall is slower than calling it directly. Using DynamicCall is pretty much like using late-binding for objects, and calling the function directly is like using early-binding.

* To pass arrays and user defined types to functions, declare the parameter as a long, and use the VarPtr function when calling the function. For example, suppose MyArray() is an array of Integer, and MyUDT is a variable of a User Defined Type:

Caller.DefineFunction "MyFunctionArray", , "%I4"
Caller.DefineFunction "MyFunctionUDT", , "%I4"
...
Caller.DoCall "MyFunctionArray", VarPtr(MyArray(0))
Caller.DoCall "MyFunctionUDT", VarPtr(MyUDT)

Note that this way of passing arrays only applies to API functions. Passing arrays to your own VB functions is somewhat complicated.

* Functions can only return static data types. Dynamic data types (strings, variants, etc) are not supported as return types.

* Be careful when using callbacks. When you are inside a function that was called by DynamicCall, you can call other functions using DynamicCall, but you cannot define new functions. You can only define new functions when you are not inside a function called by DynamicCall.

* The function definition must match exactly the function declaration. Failing to do so might result in a crash. This is actually a very powerful way of doing typecasts if you really know what you're doing.










You can use this ActiveX DLL in your programs as long as you give credits for it. I'm not responsible for whatever problem(s) you may have when using this piece of software.

Copyright � 2004 Paul Guerra. All rights reserved.